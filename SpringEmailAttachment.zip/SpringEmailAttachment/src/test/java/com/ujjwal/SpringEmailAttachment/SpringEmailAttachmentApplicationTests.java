package com.ujjwal.SpringEmailAttachment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmailAttachmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
